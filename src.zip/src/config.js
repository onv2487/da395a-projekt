const config = {
    apiKey: process.env.REACT_APP_APIKEY,
};

export default config;
